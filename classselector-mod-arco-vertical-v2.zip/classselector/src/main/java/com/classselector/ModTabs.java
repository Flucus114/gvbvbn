package com.classselector;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

/** Aba criativa do mod (hoje: Hyper Arco de Sculk e livros de Chamado do Trovão). */
public class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ClassSelectorMod.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.classselector"))
            .icon(() -> new ItemStack(ModItems.HYPER_SCULK_BOW.get()))
            .displayItems((params, out) -> {
                out.accept(ModItems.HYPER_SCULK_BOW.get());
                for (int lvl = 1; lvl <= 3; lvl++) {
                    out.accept(EnchantedBookItem.createForEnchantment(
                            new EnchantmentInstance(ModEnchantments.THUNDER_CALL.get(), lvl)));
                }
            })
            .build());
}
