package com.classselector;

import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

/** Propriedades de item "pull" e "pulling" (usadas pelos overrides do modelo) para o Hyper Arco de Sculk. */
@Mod.EventBusSubscriber(modid = ClassSelectorMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class HyperBowClient {
    private HyperBowClient() { }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent e) {
        e.enqueueWork(() -> {
            var bow = ModItems.HYPER_SCULK_BOW.get();
            ItemProperties.register(bow, new ResourceLocation("pull"), (stack, level, entity, seed) -> {
                if (entity == null || entity.getUseItem() != stack) return 0.0F;
                float ticks = stack.getUseDuration() - entity.getUseItemRemainingTicks();
                return Mth.clamp(ticks / (float) BowConfig.CHARGE_TICKS.get(), 0.0F, 1.0F);
            });
            ItemProperties.register(bow, new ResourceLocation("pulling"), (stack, level, entity, seed) ->
                    entity != null && entity.isUsingItem() && entity.getUseItem() == stack ? 1.0F : 0.0F);
        });
    }
}
