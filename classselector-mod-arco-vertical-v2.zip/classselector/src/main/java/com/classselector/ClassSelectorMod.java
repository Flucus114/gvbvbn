package com.classselector;

import com.mojang.serialization.Codec;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(ClassSelectorMod.MODID)
public class ClassSelectorMod {
    public static final String MODID = "classselector";
    /** Chave NBT (dados persistentes do jogador) com o id da classe escolhida. */
    public static final String KEY = "classselector_class";
    /** Chave NBT com o id da raça escolhida. */
    public static final String KEY_RACE = "classselector_race";

    public static final DeferredRegister<Codec<? extends IGlobalLootModifier>> LOOT_MODIFIERS =
            DeferredRegister.create(ForgeRegistries.Keys.GLOBAL_LOOT_MODIFIER_SERIALIZERS, MODID);
    public static final RegistryObject<Codec<? extends IGlobalLootModifier>> PURGE_MODIFIER =
            LOOT_MODIFIERS.register("purge", PurgeLootModifier.CODEC);

    public ClassSelectorMod() {
        LOOT_MODIFIERS.register(FMLJavaModLoadingContext.get().getModEventBus());
        ModEntities.ENTITIES.register(FMLJavaModLoadingContext.get().getModEventBus());
        ModItems.ITEMS.register(FMLJavaModLoadingContext.get().getModEventBus());
        ModEnchantments.ENCHANTMENTS.register(FMLJavaModLoadingContext.get().getModEventBus());
        ModTabs.TABS.register(FMLJavaModLoadingContext.get().getModEventBus());
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, BowConfig.SPEC);
        ModMenus.MENUS.register(FMLJavaModLoadingContext.get().getModEventBus());
        RestrictNet.register();
        Net.register();
        QuestNet.register();
        SkillNet.register();
        WardenSitNet.register();
    }
}
