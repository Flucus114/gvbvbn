package com.classselector;

import net.minecraftforge.common.ForgeConfigSpec;

/** Configuração do Hyper Arco de Sculk (arquivo config/classselector-common.toml). */
public final class BowConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.DoubleValue RANGE;
    public static final ForgeConfigSpec.IntValue CHARGE_TICKS;
    public static final ForgeConfigSpec.DoubleValue MAX_DAMAGE;
    public static final ForgeConfigSpec.DoubleValue MIN_DAMAGE;
    public static final ForgeConfigSpec.IntValue COOLDOWN_TICKS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("hyper_sculk_bow");
        RANGE = b.comment("Alcance maximo do Raio Supersonico, em blocos.")
                .defineInRange("range", 40.0D, 4.0D, 128.0D);
        CHARGE_TICKS = b.comment("Ticks para carga maxima (20 ticks = 1 s). Padrao 24 = 1,2 s.")
                .defineInRange("chargeTicks", 24, 4, 200);
        MAX_DAMAGE = b.comment("Dano com carga maxima (pontos de vida; 2 = 1 coracao).")
                .defineInRange("maxDamage", 18.0D, 0.0D, 1000.0D);
        MIN_DAMAGE = b.comment("Dano com carga minima (carga parcial).")
                .defineInRange("minDamage", 6.0D, 0.0D, 1000.0D);
        COOLDOWN_TICKS = b.comment("Recarga apos o disparo, em ticks. Padrao 40 = 2 s.")
                .defineInRange("cooldownTicks", 40, 0, 1200);
        b.pop();
        SPEC = b.build();
    }

    private BowConfig() { }
}
