package com.classselector;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;

public class WardenScreen extends AbstractContainerScreen<WardenMenu> {
    public WardenScreen(WardenMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth = 176;
        this.imageHeight = 166;
        this.inventoryLabelY = 74;
    }

    private Button sitButton;

    private Component sitLabel() {
        return Component.literal(menu.isSitting() ? "Modo: Sentado" : "Modo: Em pé");
    }

    @Override
    protected void init() {
        super.init();
        sitButton = addRenderableWidget(Button.builder(sitLabel(), b -> {
            if (minecraft != null && minecraft.gameMode != null) {
                minecraft.gameMode.handleInventoryButtonClick(menu.containerId, WardenMenu.BTN_TOGGLE_SIT);
            }
        }).bounds(leftPos + 95, topPos + 67, 76, 14).build());
    }

    @Override
    protected void containerTick() {
        super.containerTick();
        if (sitButton != null) sitButton.setMessage(sitLabel());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        super.render(g, mx, my, pt);
        renderTooltip(g, mx, my);
    }

    @Override
    protected void renderBg(GuiGraphics g, float pt, int mx, int my) {
        int x = leftPos, y = topPos, w = imageWidth, h = imageHeight;
        // painel
        g.fill(x, y, x + w, y + h, 0xFFC6C6C6);
        g.fill(x, y, x + w, y + 2, 0xFFFFFFFF);
        g.fill(x, y, x + 2, y + h, 0xFFFFFFFF);
        g.fill(x, y + h - 2, x + w, y + h, 0xFF555555);
        g.fill(x + w - 2, y, x + w, y + h, 0xFF555555);
        // caixa de visualização do Warden
        g.fill(x + 8, y + 16, x + 78, y + 70, 0xFF373737);
        g.fill(x + 9, y + 17, x + 78, y + 70, 0xFFFFFFFF);
        g.fill(x + 9, y + 17, x + 77, y + 69, 0xFF14141C);
        // slots
        for (Slot s : menu.slots) {
            int sx = x + s.x - 1, sy = y + s.y - 1;
            g.fill(sx, sy, sx + 18, sy + 18, 0xFF373737);
            g.fill(sx + 1, sy + 1, sx + 18, sy + 18, 0xFFFFFFFF);
            g.fill(sx + 1, sy + 1, sx + 17, sy + 17, 0xFF8B8B8B);
        }
        g.drawString(font, "Capacete", x + 120, y + 28, 0x404040, false);
        g.drawString(font, "Estandarte", x + 120, y + 52, 0x404040, false);
        if (menu.warden != null) {
            InventoryScreen.renderEntityInInventoryFollowsMouse(g, x + 43, y + 66, 16,
                    (float) (x + 43 - mx), (float) (y + 30 - my), menu.warden);
        }
    }
}
