package com.classselector;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Habilidades já desbloqueadas por cada jogador. */
public class PlayerSkillData extends SavedData {
    public final Map<UUID, Set<String>> players = new HashMap<>();

    public static PlayerSkillData get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(PlayerSkillData::load, PlayerSkillData::new, "classselector_skill_progress");
    }

    public Set<String> of(UUID id) { return players.computeIfAbsent(id, k -> new HashSet<>()); }

    public static PlayerSkillData load(CompoundTag tag) {
        PlayerSkillData d = new PlayerSkillData();
        for (Tag t : tag.getList("players", Tag.TAG_COMPOUND)) {
            CompoundTag c = (CompoundTag) t;
            UUID id;
            try { id = UUID.fromString(c.getString("uuid")); } catch (Exception e) { continue; }
            Set<String> set = d.of(id);
            for (Tag s : c.getList("unlocked", Tag.TAG_STRING)) set.add(s.getAsString());
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag l = new ListTag();
        for (Map.Entry<UUID, Set<String>> e : players.entrySet()) {
            CompoundTag c = new CompoundTag();
            c.putString("uuid", e.getKey().toString());
            ListTag ul = new ListTag();
            for (String s : e.getValue()) ul.add(StringTag.valueOf(s));
            c.put("unlocked", ul);
            l.add(c);
        }
        tag.put("players", l);
        return tag;
    }
}
