#!/usr/bin/env python3
"""Constrói o Hyper Arco de Sculk (modelos JSON de item + atlas de textura) a partir da folha de arte
modelsrc/hyper_arco_sculk_art.png.

- A vista principal (arco com o olho no centro) vira a face lateral do arco: a silhueta é "voxelizada"
  (voxel = 0,4 px) e extrudada em Z; as faces ±Z usam a própria arte como textura (janelas de UV no atlas).
- O arco é curvado levemente (pontas voltadas para a corda), como um arco de verdade.
- Orientação: ventre (lado do olho e dos espinhos) para FRENTE (+X local = direção do disparo),
  corda e "costas" voltadas para o JOGADOR. Para inverter, mude FORWARD_IS_BELLY para False.
- A corda é feita de cubos finos com a faixa de corda da arte e recua quando o arco é puxado.

IMPORTANTE (formato do Minecraft): os UVs do JSON são sempre em 0..16, qualquer que seja a resolução da textura.
Uso: python3 build_bow.py
"""
import json, os, math
import numpy as np
from PIL import Image

ROOT = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(ROOT, "src/main/resources/assets/classselector")
ART = os.path.join(ROOT, "modelsrc/hyper_arco_sculk_art.png")
NAME = "hyper_sculk_bow"
FORWARD_IS_BELLY = True      # True: olho/espinhos para frente, corda para o jogador

VX = 0.4                      # tamanho do voxel em px do modelo
HV, WV = 66, 17               # grade do arco (26,4 x 6,8 px)
SC = 1145.0 / HV              # px da arte por voxel
ART_X0, ART_Y0 = 22, 22       # canto do arco principal na folha
EYE = (143.5, 571.1)          # centro do olho na folha
BASE_DEPTH, CORE_DEPTH, CORE_R = 4, 6, 3.2   # espessura em voxels
TW, TH = 64, 160              # atlas
TEX_A = (0, 0)                # arco: 34x132 texels (2 por voxel)
TEX_S = (36, 0)               # faixa da corda: 8x132
TEX_H = (46, 0)               # tile do halo: 8x8

art = Image.open(ART).convert("RGB")
crop = art.crop((ART_X0, ART_Y0, int(ART_X0 + WV * SC), int(ART_Y0 + HV * SC)))
a = np.array(crop).astype(float); lum = a.sum(2) / 3

# --- máscara de voxels ---
mask = np.zeros((HV, WV), bool)
for r in range(HV):
    for c in range(WV):
        blk = lum[int(r * SC):int((r + 1) * SC), int(c * SC):int((c + 1) * SC)]
        mask[r, c] = blk.size and (blk > 24).mean() >= 0.22
for _ in range(2):  # fecha buracos pequenos
    nb = np.zeros_like(mask, int)
    nb[1:] += mask[:-1]; nb[:-1] += mask[1:]; nb[:, 1:] += mask[:, :-1]; nb[:, :-1] += mask[:, 1:]
    mask |= (nb >= 3)

eye_c = (EYE[0] - ART_X0) / SC; eye_r = (EYE[1] - ART_Y0) / SC
def depth(r, c):
    return CORE_DEPTH if (c + .5 - eye_c) ** 2 + (r + .5 - eye_r) ** 2 <= CORE_R ** 2 else BASE_DEPTH
# Curvatura calculada a partir da própria arte: as pontas encostam na corda (linha geo x=0) e o meio do arco
# fica afastado dela (GAP voxels), deixando a corda livre e visível entre as pontas.
rows_f = [r for r in range(HV) if mask[r].any()]
def _centre(r):
    cs = [c for c in range(WV) if mask[r, c]]
    return sum(cs) / len(cs) + 0.5
C_TIP = sum(_centre(r) for r in rows_f[:3] + rows_f[-3:]) / 6.0
L_MID = min(c for r in range(HV // 2 - 10, HV // 2 + 10) for c in range(WV) if mask[r, c])
GAP = 1.5
O_TIP, O_MID = -C_TIP, GAP - L_MID          # deslocamento (voxels, +x) nas pontas e no meio
def shift(r):   # s = -deslocamento ; coluna geo = c - s
    t = (r + .5 - HV / 2) / (HV / 2)
    return -int(round(O_TIP + (O_MID - O_TIP) * (1.0 - t * t)))

# --- atlas ---
atlas = Image.new("RGBA", (TW, TH), (0, 0, 0, 0))
bow_tex = crop.resize((WV * 2, HV * 2), Image.BOX)
atlas.paste(bow_tex.convert("RGBA"), TEX_A)
# faixa da corda: perfil de brilho da corda da arte (coluna central) -> nós luminosos ao longo do comprimento
prof = lum_sheet = np.array(art.convert("L")).astype(float)[22:1167, 806:824].mean(1)
prof = np.array(Image.fromarray(prof[:, None].astype(np.uint8)).resize((1, HV * 2), Image.BOX)).astype(float)[:, 0]
prof = (prof - prof.min()) / max(1e-6, prof.max() - prof.min())
prof = prof ** 1.3
def lerp(c0, c1, t): return tuple(int(c0[i] + (c1[i] - c0[i]) * t) for i in range(3))
for y in range(HV * 2):
    t = float(prof[y])
    centre = lerp((40, 205, 245), (240, 255, 255), t)
    side = lerp((8, 85, 135), (40, 200, 240), t)
    for x, col in enumerate([side, centre, centre, side]):
        atlas.putpixel((TEX_S[0] + x, TEX_S[1] + y), col + (255,))
halo = Image.new("RGBA", (8, 8), (36, 200, 245, 255))
for y in range(8):
    for x in range(8):
        d = ((x - 3.5) ** 2 + (y - 3.5) ** 2) ** .5
        halo.putpixel((x, y), (235, 255, 255, 255) if d < 1.6 else (112, 245, 255, 255) if d < 2.8 else (36, 200, 245, 255))
atlas.paste(halo, TEX_H)
os.makedirs(os.path.join(RES, "textures/item"), exist_ok=True)
atlas.save(os.path.join(RES, f"textures/item/{NAME}.png"))

def uv(x0, y0, x1, y1, inset=0.2):
    """texels do atlas -> UV do Minecraft (0..16)."""
    fx = 16.0 / TW; fy = 16.0 / TH
    return [round((x0 + inset) * fx, 4), round((y0 + inset) * fy, 4), round((x1 - inset) * fx, 4), round((y1 - inset) * fy, 4)]
def uv_cells(c0, r0, c1, r1, flip_u=False):
    u0, v0 = TEX_A[0] + c0 * 2, TEX_A[1] + r0 * 2
    u1, v1 = TEX_A[0] + (c1 + 1) * 2, TEX_A[1] + (r1 + 1) * 2
    q = uv(u0, v0, u1, v1)
    return [q[2], q[1], q[0], q[3]] if flip_u else q

# --- coordenadas locais ---
XL0 = 8.9 - (eye_c - shift(int(eye_r))) * VX
YTOP = 8.0 + eye_r * VX
ZC = 8.0
def gx(c): return XL0 + c * VX
def gy(r): return YTOP - r * VX
ROT = {"angle": 45, "axis": "z", "origin": [8, 8, 8]}
def r4(v): return round(v, 4)

cells = {}   # (c_geo, r) -> (c_src, depth)
for r in range(HV):
    s = shift(r)
    for c in range(WV):
        if mask[r, c]:
            cells[(c - s, r)] = (c, depth(r, c))

body = []
def plane(frm, to, face, uvr):
    body.append({"from": [r4(v) for v in frm], "to": [r4(v) for v in to], "rotation": ROT,
                 "faces": {face: {"uv": uvr, "texture": "#0"}}})

# faces grandes ±Z (fundidas em retângulos com mesmo shift e mesma espessura)
done = set()
for r in range(HV):
    s = shift(r)
    for c in range(WV):
        if not mask[r, c] or (r, c) in done: continue
        d = depth(r, c)
        def ok(rr, cc): return 0 <= rr < HV and 0 <= cc < WV and mask[rr, cc] and (rr, cc) not in done and depth(rr, cc) == d
        c1 = c
        while ok(r, c1 + 1): c1 += 1
        r1 = r
        while r1 + 1 < HV and shift(r1 + 1) == s and all(ok(r1 + 1, cc) for cc in range(c, c1 + 1)): r1 += 1
        for rr in range(r, r1 + 1):
            for cc in range(c, c1 + 1): done.add((rr, cc))
        xa, xb = gx(c - s), gx(c1 + 1 - s)
        ya, yb = gy(r1 + 1), gy(r)
        zf, zb = ZC + d * VX / 2, ZC - d * VX / 2
        plane([xa, ya, zf], [xb, yb, zf], "south", uv_cells(c, r, c1, r1))
        plane([xa, ya, zb], [xb, yb, zb], "north", uv_cells(c, r, c1, r1, flip_u=True))

# paredes (contorno e degraus de espessura)
def wall_pieces(d, dn):
    if dn <= 0: return [(-d / 2, d / 2)]
    return [(dn / 2, d / 2), (-d / 2, -dn / 2)]
for (gc, r), (c, d) in cells.items():
    win = uv_cells(c, r, c, r)
    for face, (dc, dr) in {"east": (1, 0), "west": (-1, 0), "up": (0, -1), "down": (0, 1)}.items():
        nb = cells.get((gc + dc, r + dr))
        dn = nb[1] if nb else 0
        if dn >= d: continue
        for (z0, z1) in wall_pieces(d, dn):
            za, zb = ZC + z0 * VX, ZC + z1 * VX
            if face in ("east", "west"):
                x = gx(gc + 1) if face == "east" else gx(gc)
                plane([x, gy(r + 1), za], [x, gy(r), zb], face, win)
            else:
                y = gy(r) if face == "up" else gy(r + 1)
                plane([gx(gc), y, za], [gx(gc + 1), y, zb], face, win)

# --- corda ---
rows = [r for r in range(HV) if mask[r].any()]
R0, R1 = min(rows), max(rows) + 1
tip_cols = []
for r in rows[:3] + rows[-3:]:
    cs = [c for c in range(WV) if mask[r, c]]
    tip_cols.append(sum(cs) / len(cs) - shift(r) + 0.5)
SW = 0.6                                       # espessura da corda (px)
STR_C = sum(tip_cols) / len(tip_cols)           # coluna (geo) da corda
def cube(a_, b_, tex_uv):
    faces = {d_: {"uv": tex_uv, "texture": "#0"} for d_ in ("north", "east", "south", "west", "up", "down")}
    return {"from": [r4(v) for v in a_], "to": [r4(v) for v in b_], "rotation": ROT, "faces": faces}
def string(shift_vox, halo_on):
    els = []; n = R1 - R0; mid = (R0 + R1) / 2.0; half = n / 2.0
    sh = [int(round(shift_vox * (1.0 - abs(R0 + k + .5 - mid) / half))) for k in range(n)]
    k = 0
    while k < n:
        k2 = k
        while k2 + 1 < n and sh[k2 + 1] == sh[k]: k2 += 1
        xa = gx(STR_C) - SW / 2 - sh[k] * VX
        u = uv(TEX_S[0], TEX_S[1] + (R0 + k) * 2, TEX_S[0] + 4, TEX_S[1] + (R0 + k2 + 1) * 2)
        els.append(cube([xa, gy(R0 + k2 + 1), ZC - SW / 2], [xa + SW, gy(R0 + k), ZC + SW / 2], u))
        k = k2 + 1
    if halo_on:   # carga máxima: halo em volta do olho
        ex, ey = gx(eye_c), gy(eye_r)
        hu = uv(TEX_H[0], TEX_H[1], TEX_H[0] + 8, TEX_H[1] + 8)
        for dx, dy in [(3.4, 0), (-3.4, 0), (0, 3.4), (0, -3.4), (2.4, 2.4), (-2.4, 2.4), (2.4, -2.4), (-2.4, -2.4)]:
            els.append(cube([ex + dx - .3, ey + dy - .3, ZC + 1.2], [ex + dx + .3, ey + dy + .3, ZC + 1.8], hu))
    return els

# --- orientação (ventre para frente = +X local) ---
def orient(els):
    if FORWARD_IS_BELLY: return els
    out = []   # espelha em X em torno de 8 (inverte frente/costas)
    for e in els:
        e = json.loads(json.dumps(e))
        x0, x1 = e["from"][0], e["to"][0]
        e["from"][0], e["to"][0] = r4(16 - x1), r4(16 - x0)
        out.append(e)
    return out

S3, S1, SG = 0.85, 0.5, 0.75
# Primeira pessoa: limbos quase na VERTICAL, ventre (olho) apontando PARA FRENTE (rumo à mira), corda para o jogador.
# FP_Y = guinada do ventre: 90 = exatamente para frente (-Z da câmera). Cada grau a menos desvia ~1° para a DIREITA
#        (com 60 o ventre ficava 30° para a direita, que é o que se via apontando para o lado).
# FP_Z = inclinação no plano do arco: 45 - |FP_Z| = elevação do ventre em repouso; limbos ficam na vertical em -45.
#        -35 deixa o ventre ~10° para cima em repouso e ~10° para baixo carregando (a animação vanilla de puxar o arco
#        já abaixa a ponta), então a mira fica equilibrada nos dois estados.
FP_Y, FP_Z = 90, -35
DISPLAY = {
    "thirdperson_righthand": {"rotation": [-80, 260, -40], "translation": [-1, -2, 2.5], "scale": [S3] * 3},
    "thirdperson_lefthand":  {"rotation": [-80, -280, 40], "translation": [-1, -2, 2.5], "scale": [S3] * 3},
    "firstperson_righthand": {"rotation": [0, FP_Y, FP_Z], "translation": [1.5, 3.5, 0], "scale": [S1] * 3},
    "firstperson_lefthand":  {"rotation": [0, -FP_Y, -FP_Z], "translation": [1.5, 3.5, 0], "scale": [S1] * 3},
    "gui":    {"rotation": [0, 0, 0], "translation": [0, 0, 0], "scale": [SG] * 3},
    "fixed":  {"rotation": [0, 0, 0], "translation": [0, 0, 0], "scale": [SG] * 3},
    "ground": {"rotation": [0, 0, 0], "translation": [0, 3, 0], "scale": [0.5] * 3},
}
def model(shift_vox, halo_on=False, overrides=None):
    els = orient(body + string(shift_vox, halo_on))
    for e in els:
        assert all(-16 <= v <= 32 for v in e["from"] + e["to"]), e
    m = {"textures": {"0": f"classselector:item/{NAME}", "particle": f"classselector:item/{NAME}"},
         "elements": els, "display": DISPLAY}
    if overrides: m["overrides"] = overrides
    return m
d = os.path.join(RES, "models/item"); os.makedirs(d, exist_ok=True)
def save(name, m):
    with open(os.path.join(d, name + ".json"), "w", encoding="utf-8") as f:
        json.dump(m, f, separators=(",", ":"))
ov = [
    {"predicate": {"pulling": 1}, "model": f"classselector:item/{NAME}_pulling_0"},
    {"predicate": {"pulling": 1, "pull": 0.4}, "model": f"classselector:item/{NAME}_pulling_1"},
    {"predicate": {"pulling": 1, "pull": 0.8}, "model": f"classselector:item/{NAME}_pulling_2"},
    {"predicate": {"pulling": 1, "pull": 1.0}, "model": f"classselector:item/{NAME}_pulling_3"},
]
save(NAME, model(0, overrides=ov))
save(f"{NAME}_pulling_0", model(3)); save(f"{NAME}_pulling_1", model(6))
save(f"{NAME}_pulling_2", model(9)); save(f"{NAME}_pulling_3", model(11))
print("voxels:", int(mask.sum()), "| elementos do corpo:", len(body), "| corda: linhas", R1 - R0)
